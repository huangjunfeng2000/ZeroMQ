# FileMQ implementation in Java

## How to use

Add it to your Maven project's `pom.xml`:

    <!-- for the FileMQ using jzmq -->
    <dependency>
      <groupId>org.filemq</groupId>
      <artifactId>filemq</artifactId>
      <version>0.1.0-SNAPSHOT</version>
    </dependency>

    <!-- for the FileMQ using JeroMQ -->
    <dependency>
      <groupId>org.filemq</groupId>
      <artifactId>filemq-jeromq</artifactId>
      <version>0.1.0-SNAPSHOT</version>
    </dependency>
