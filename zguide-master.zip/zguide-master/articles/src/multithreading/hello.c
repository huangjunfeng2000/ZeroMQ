#include "zmsg.c"
void main (void) 
{
    s_version ();
}
