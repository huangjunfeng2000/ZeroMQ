#!/usr/bin/env julia

using ZMQ

println("Current ZMQ version is $(ZMQ.version)")